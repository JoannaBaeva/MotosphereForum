﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotorcycleForum.Data.Enums
{
    public enum VoteType
    {
        Upvote = 1,
        Downvote = -1
    }
}
