﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MotorcycleForum.Web.Areas.Identity.Pages.Account
{
    public class BannedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}