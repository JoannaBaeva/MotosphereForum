﻿namespace MotorcycleForum.Services.Models.Admin
{
    public class AdminDashboardViewModel
    {
        public int TotalUsers { get; set; }
        public int ForumPostsCount { get; set; }
        public int MarketplaceListingsCount { get; set; }
        public int EventsCount { get; set; }
    }

}
